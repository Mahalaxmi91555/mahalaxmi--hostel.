# Mahalaxmi Girl's Hostel Website
Upload all files to a GitHub repository, then deploy with GitHub Pages.